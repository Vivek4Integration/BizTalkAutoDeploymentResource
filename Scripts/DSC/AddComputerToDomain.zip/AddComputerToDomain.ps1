﻿configuration AddComputerToDomain{

param 
    ( 
       
 
        [Parameter(Mandatory)] 
        [string]$MachineName,
 
        [Parameter(Mandatory)] 
        [string]$DomainName,
 
        [Parameter(Mandatory)] 
        [pscredential]$AdminCreds
    ) 
 
  Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -Module xComputerManagement 
  [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("$DomainName\$($AdminCreds.UserName)", $AdminCreds.Password)

    Node "localhost"
    { 
     LocalConfigurationManager
        {
            ActionAfterReboot = 'ContinueConfiguration'
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
            AllowModuleOverWrite = $true
        }
        xComputer JoinDomain 
        { 
            Name          = $MachineName
            DomainName    = $DomainName
            Credential    = $DomainCreds
        } 
    } 

}