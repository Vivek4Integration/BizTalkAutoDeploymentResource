﻿configuration CreateADDomain
{ 
    param 
    ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AdminCreds,

        [Int]$RetryCount = 20,
        [Int]$RetryIntervalSec = 30
    ) 
    
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName xActiveDirectory
    Import-DscResource -ModuleName xSystemSecurity
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("$DomainName\$($AdminCreds.UserName)", $AdminCreds.Password)

    Node $AllNodes.Nodename
    {
        LocalConfigurationManager {
            ActionAfterReboot    = 'ContinueConfiguration'
            ConfigurationMode    = 'ApplyOnly'
            RebootNodeIfNeeded   = $true
            AllowModuleOverWrite = $true
        }

        
        xUAC DisableUAC {
            Setting = "NeverNotifyAndDisableAll"
        }

        
        
        WindowsFeature IIS {
            Ensure = 'Present'
            Name   = "Web-Server"
        }

        WindowsFeature IISManagementTools {
            Ensure               = 'Present'
            Name                 = "Web-Mgmt-Tools"
            IncludeAllSubFeature = $True
            DependsOn            = '[WindowsFeature]IIS'
        }
        WindowsFeature ADDSInstall { 
            Ensure    = 'Present'
            Name      = 'AD-Domain-Services'
            DependsOn = '[xUAC]DisableUAC'
        }

        
        WindowsFeature ADDSTools { 
            Ensure    = 'Present' 
            Name      = 'RSAT-ADDS' 
            DependsOn = '[WindowsFeature]ADDSInstall'

        }
       



        xADDomain FirstDS {
            DomainName                    = $DomainName
            DomainAdministratorCredential = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            DatabasePath                  = 'C:\NTDS'
            LogPath                       = 'C:\NTDS'
            SysvolPath                    = 'C:\SYSVOL'
            DependsOn                     = "[WindowsFeature]ADDSTools"
        }

        xWaitForADDomain DscForestWait {
            DomainName           = $DomainName
            DomainUserCredential = $DomainCreds
            RetryCount           = $RetryCount
            RetryIntervalSec     = $RetryIntervalSec
            DependsOn            = "[xADDomain]FirstDS"
        } 

        

        $Users = $ConfigurationData.NonNodeData.UserData | ConvertFrom-CSV
        ForEach ($User in $Users) {

            xADUser "CreateADUser" {
                DomainName           = $DomainName
                Ensure               = 'Present'
                UserName             = $User.UserName
                Description          = $User.Description
                Enabled              = $true
                Password             = New-Object -TypeName PSCredential -ArgumentList 'JustPassword', (ConvertTo-SecureString -String $User.Password -AsPlainText -Force)
                PasswordNeverExpires = $true
                DependsOn            = '[xWaitForADDomain]DscForestWait'
            }
            
        }
     
       
        $Groups = $ConfigurationData.NonNodeData.GroupData | ConvertFrom-CSV
        ForEach ($Group in $Groups) {
            xADGroup "$Group.Name" {
                GroupName        = $Group.Name
                GroupScope       = 'Global'
                Description      = $Group.Description
                Category         = 'Security'
                MembersToInclude = $Group.Member
                Ensure           = 'Present'
                DependsOn        = "[xADUser]CreateADUser"
            }
        }

        Registry DisableBiometrics {
            Ensure    = "Present"
            Key       = "HKLM:\SOFTWARE\BizTalkDeployment\DomainEnabled"
            ValueName = "Enabled"
            ValueData = "1"
            ValueType = "Dword" 
            DependsOn = "[xADUser]CreateADUser"

        }

    }
}
